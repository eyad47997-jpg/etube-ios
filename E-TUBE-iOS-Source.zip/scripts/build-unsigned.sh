#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v xcodebuild >/dev/null || { echo 'Xcode on macOS is required.' >&2; exit 1; }
command -v xcodegen >/dev/null || { echo 'Install XcodeGen first: brew install xcodegen' >&2; exit 1; }
xcodegen generate
xcodebuild -project ETUBE.xcodeproj -scheme ETUBE -configuration Release \
  -destination 'generic/platform=iOS' -archivePath "$PWD/build/ETUBE.xcarchive" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO archive
APP_PATH="$PWD/build/ETUBE.xcarchive/Products/Applications/ETUBE.app"
test -f "$APP_PATH/ETUBE"
mkdir -p build/ipa/Payload
cp -R "$APP_PATH" build/ipa/Payload/
(cd build/ipa && /usr/bin/zip -qry ../E-TUBE-unsigned.ipa Payload)
python3 scripts/verify-package.py build/E-TUBE-unsigned.ipa
echo 'Created build/E-TUBE-unsigned.ipa. It must be signed before installation.'
