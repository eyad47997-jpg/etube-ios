import plistlib
import sys
import zipfile
from pathlib import Path

ipa = Path(sys.argv[1])
with zipfile.ZipFile(ipa) as z:
    root = 'Payload/ETUBE.app/'
    info = plistlib.loads(z.read(root + 'Info.plist'))
    assert info['CFBundleDisplayName'] == 'E/TUBE'
    executable = info['CFBundleExecutable']
    binary = z.read(root + executable)
    assert binary[:4] == b'\xcf\xfa\xed\xfe', 'Missing 64-bit Mach-O binary'
    assert int.from_bytes(binary[4:8], 'little') == 0x0100000C, 'Expected arm64 iPhone executable'
    assert len(binary) > 4096
print(f'Validated IPA structure and compiled executable: {ipa.name}. This does not validate signing or device behavior.')
