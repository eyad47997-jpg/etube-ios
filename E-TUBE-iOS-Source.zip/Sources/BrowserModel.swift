import Combine
import Foundation
import UIKit
import WebKit

final class BrowserModel: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate {
    static let home = URL(string: "https://eyad-tube-nov26.annualgala8.chatgpt.site/")!
    let webView: WKWebView
    @Published var progress: Double = 0
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var errorMessage: String?
    @Published var notice: String?
    private var observations: [NSKeyValueObservation] = []

    override init() {
        let configuration = WKWebViewConfiguration()
        configuration.allowsInlineMediaPlayback = true
        configuration.allowsPictureInPictureMediaPlayback = true
        configuration.allowsAirPlayForMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []
        configuration.websiteDataStore = .default()
        webView = WKWebView(frame: .zero, configuration: configuration)
        super.init()
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 16/255, green: 17/255, blue: 21/255, alpha: 1)
        webView.scrollView.backgroundColor = webView.backgroundColor
        observations = [
            webView.observe(\.estimatedProgress, options: [.new]) { [weak self] view, _ in
                DispatchQueue.main.async { self?.progress = view.estimatedProgress }
            },
            webView.observe(\.canGoBack, options: [.new]) { [weak self] view, _ in
                DispatchQueue.main.async { self?.canGoBack = view.canGoBack }
            },
            webView.observe(\.canGoForward, options: [.new]) { [weak self] view, _ in
                DispatchQueue.main.async { self?.canGoForward = view.canGoForward }
            }
        ]
        loadHome()
    }

    func loadHome() { errorMessage = nil; webView.load(URLRequest(url: Self.home)) }
    func reload() {
        errorMessage = nil
        if webView.url == nil { loadHome() } else { webView.reload() }
    }
    func openInSafari() {
        let current = webView.url
        UIApplication.shared.open(current?.scheme == "https" ? current! : Self.home)
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        errorMessage = nil
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        report(error)
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        report(error)
    }
    private func report(_ error: Error) {
        guard (error as NSError).code != NSURLErrorCancelled else { return }
        errorMessage = "تعذر فتح E/TUBE. تأكد من اتصال الإنترنت وحاول مرة أخرى."
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        errorMessage = "أوقف iOS صفحة الموقع. اضغط إعادة المحاولة لاستعادتها."
    }
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url else { decisionHandler(.cancel); return }
        // Embedded YouTube frames must remain inside their own origins.
        if action.targetFrame?.isMainFrame == false { decisionHandler(.allow); return }
        if url.pathExtension.lowercased() == "apk" {
            notice = "ملف APK لأندرويد فقط. أنت بالفعل تستخدم نسخة الآيفون."
            decisionHandler(.cancel); return
        }
        if url.scheme == "https", url.host == Self.home.host {
            decisionHandler(.allow); return
        }
        if ["https", "mailto", "tel"].contains(url.scheme ?? "") {
            UIApplication.shared.open(url)
        } else if url.absoluteString == "about:blank" {
            decisionHandler(.allow); return
        }
        decisionHandler(.cancel)
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = action.request.url, url.scheme == "https" { UIApplication.shared.open(url) }
        return nil
    }
    func webView(_ webView: WKWebView, requestMediaCapturePermissionFor origin: WKSecurityOrigin,
                 initiatedByFrame frame: WKFrameInfo, type: WKMediaCaptureType,
                 decisionHandler: @escaping (WKPermissionDecision) -> Void) {
        // Never silently grant camera or microphone access.
        decisionHandler(origin.host == Self.home.host ? .prompt : .deny)
    }
}
