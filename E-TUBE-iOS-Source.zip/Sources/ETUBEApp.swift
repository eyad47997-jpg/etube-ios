import SwiftUI

@main
struct ETUBEApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
