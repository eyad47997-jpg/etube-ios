import SwiftUI
import WebKit
import AVKit

struct AirPlayButton: UIViewRepresentable {
    func makeUIView(context: Context) -> AVRoutePickerView {
        let picker = AVRoutePickerView()
        picker.prioritizesVideoDevices = true
        picker.tintColor = .white
        picker.activeTintColor = UIColor(red: 184/255, green: 246/255, blue: 102/255, alpha: 1)
        picker.accessibilityLabel = "AirPlay: اختر شاشة متوافقة أثناء توقف السيارة"
        return picker
    }
    func updateUIView(_ uiView: AVRoutePickerView, context: Context) {}
}

struct SiteView: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct ContentView: View {
    @StateObject private var browser = BrowserModel()
    @State private var showAbout = false
    private let lime = Color(red: 184/255, green: 246/255, blue: 102/255)
    private let background = Color(red: 16/255, green: 17/255, blue: 21/255)

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Image("BrandMark").resizable().scaledToFit().frame(width: 42, height: 42)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                Text("E/TUBE").font(.headline).foregroundStyle(lime)
                Spacer()
                AirPlayButton().frame(width: 34, height: 34)
                Button { browser.reload() } label: { Image(systemName: "arrow.clockwise") }
                    .accessibilityLabel("تحديث الموقع")
                Menu {
                    Button("الرئيسية", systemImage: "house") { browser.loadHome() }
                    Button("فتح في Safari", systemImage: "safari") { browser.openInSafari() }
                    ShareLink(item: BrowserModel.home) { Label("مشاركة الرابط", systemImage: "square.and.arrow.up") }
                    Button("عن نسخة الآيفون", systemImage: "info.circle") { showAbout = true }
                } label: { Image(systemName: "ellipsis.circle").padding(.leading, 8) }
                .accessibilityLabel("خيارات التطبيق")
            }
            .padding(.horizontal, 16).frame(height: 58)
            if browser.progress > 0 && browser.progress < 1 {
                ProgressView(value: browser.progress).tint(lime)
            }
            ZStack {
                SiteView(webView: browser.webView)
                if let message = browser.errorMessage {
                    VStack(spacing: 18) {
                        Image(systemName: "wifi.exclamationmark").font(.largeTitle).foregroundStyle(lime)
                        Text(message).multilineTextAlignment(.center)
                        Button("إعادة المحاولة") { browser.reload() }
                            .buttonStyle(.borderedProminent).tint(lime).foregroundStyle(.black)
                    }.padding(30).frame(maxWidth: .infinity, maxHeight: .infinity).background(background)
                }
            }
            HStack(spacing: 40) {
                Button { browser.webView.goBack() } label: { Image(systemName: "chevron.left") }
                    .disabled(!browser.canGoBack).accessibilityLabel("رجوع")
                Button { browser.loadHome() } label: { Image(systemName: "house") }
                    .accessibilityLabel("الرئيسية")
                Button { browser.webView.goForward() } label: { Image(systemName: "chevron.right") }
                    .disabled(!browser.canGoForward).accessibilityLabel("تقدم")
                Button { browser.openInSafari() } label: { Image(systemName: "safari") }
                    .accessibilityLabel("فتح في Safari")
            }.frame(maxWidth: .infinity).frame(height: 48)
        }
        .background(background).foregroundStyle(.white).tint(lime).preferredColorScheme(.dark)
        .environment(\.layoutDirection, .leftToRight)
        .sheet(isPresented: $showAbout) {
            VStack(spacing: 20) {
                Image("BrandMark").resizable().scaledToFit().frame(width: 110, height: 110)
                Text("E/TUBE · iPhone").font(.title2.bold())
                Text("نسخة تطبيق تعرض موقع E/TUBE داخل iOS. تحتاج اتصال إنترنت. مشغّل يوتيوب قد يعرض إعلانات.")
                Text("هذه النسخة لا تضيف التقاطًا أصليًا لشاشة الآيفون ولا تضمن بث الشاشة في الخلفية. إذا كانت مشاركة الشاشة غير متاحة داخل التطبيق، افتح الموقع في Safari.")
                    .font(.footnote).foregroundStyle(.secondary)
                Text("زر AirPlay يعرض الأجهزة المتاحة. فيديو CarPlay يحتاج سيارة تدعم video-in-car ويعمل أثناء التوقف فقط. لم يتم تفعيل صلاحية تطبيق CarPlay مستقل من Apple.")
                    .font(.footnote).foregroundStyle(.secondary)
                Button("فتح في Safari") { browser.openInSafari() }
                Button("إغلاق") { showAbout = false }.buttonStyle(.borderedProminent)
            }.multilineTextAlignment(.center).padding(28).presentationDetents([.medium, .large])
                .environment(\.layoutDirection, .rightToLeft)
        }
        .alert("E/TUBE", isPresented: Binding(get: { browser.notice != nil }, set: { if !$0 { browser.notice = nil } })) {
            Button("تمام") { browser.notice = nil }
        } message: { Text(browser.notice ?? "") }
    }
}
